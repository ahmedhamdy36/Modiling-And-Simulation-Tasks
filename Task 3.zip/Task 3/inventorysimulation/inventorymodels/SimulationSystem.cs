﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace InventoryModels
{
    public class SimulationSystem
    {
        public SimulationSystem()
        {
            DemandDistribution = new List<Distribution>();
            LeadDaysDistribution = new List<Distribution>();
            SimulationCases = new List<SimulationCase>();
            PerformanceMeasures = new PerformanceMeasures();
        }

        ///////////// INPUTS /////////////

        public int OrderUpTo { get; set; }
        public int ReviewPeriod { get; set; }
        public int NumberOfDays { get; set; }
        public int StartInventoryQuantity { get; set; }
        public int StartLeadDays { get; set; }
        public int StartOrderQuantity { get; set; }
        public List<Distribution> DemandDistribution { get; set; }
        public List<Distribution> LeadDaysDistribution { get; set; }

        ///////////// OUTPUTS /////////////

        public List<SimulationCase> SimulationCases { get; set; }
        public PerformanceMeasures PerformanceMeasures { get; set; }

        public SimulationSystem(String file)
        {
            this.SimulationCases = new List<SimulationCase>();
            this.PerformanceMeasures = new PerformanceMeasures();
            this.DemandDistribution = new List<Distribution>();
            this.LeadDaysDistribution = new List<Distribution>();

            FileStream f = new FileStream(file, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(f);
            String line;

            try
            {
                line = sr.ReadLine();
                while (line != null)
                {
                     if (line.Contains("OrderUpTo"))
                    {
                        line = sr.ReadLine();

                        this.OrderUpTo = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                     else if (line.Contains("ReviewPeriod"))
                    {
                        line = sr.ReadLine();

                        this.ReviewPeriod = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                     else if (line.Contains("StartInventoryQuantity"))
                    {
                        line = sr.ReadLine();

                        this.StartInventoryQuantity = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                     
                     else if (line.Contains("StartLeadDays"))
                    {
                        line = sr.ReadLine();

                        this.StartLeadDays = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                     else if (line.Contains("StartOrderQuantity"))
                    {
                        line = sr.ReadLine();

                        this.StartOrderQuantity = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                     else if (line.Contains("NumberOfDays"))
                    {
                        line = sr.ReadLine();

                        this.NumberOfDays = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                     else if (line.Contains("DemandDistribution"))
                     {
                         while (true)
                        {
                            line = sr.ReadLine();

                            if (line == "" || line == null)
                                break;
                            Distribution tmp = new Distribution();
                            string[] arr = line.Split(',');
                            tmp.Value = int.Parse(arr[0]);
                            tmp.Probability=decimal.Parse(arr[1]);
                            this.DemandDistribution.Add(tmp);

                        }
                         line = sr.ReadLine();
                         
                     }
                     else if (line.Contains("LeadDaysDistribution"))
                    {
                         while (true)
                        {
                            line = sr.ReadLine();

                            if (line == "" || line == null)
                                break;
                            Distribution tmp = new Distribution();
                            string[] arr = line.Split(',');
                            tmp.Value = int.Parse(arr[0]);
                            tmp.Probability=decimal.Parse(arr[1]);
                            this.LeadDaysDistribution.Add(tmp);

                        }

                         line = sr.ReadLine();
                         line = sr.ReadLine();
                    }

                }
                //--- Cummulative Probability for semulation table ---//
                for (int i = 0; i < DemandDistribution.Count; i++)
                {
                    if (i == 0)
                    {
                        DemandDistribution[i].CummProbability = DemandDistribution[i].Probability;
                        DemandDistribution[i].MinRange = 1;
                        DemandDistribution[i].MaxRange = (int)(DemandDistribution[i].CummProbability * 100);
                    }
                    else
                    {
                        DemandDistribution[i].CummProbability = DemandDistribution[i].Probability + DemandDistribution[i - 1].CummProbability;
                        DemandDistribution[i].MinRange = DemandDistribution[i-1].MaxRange + 1;
                        DemandDistribution[i].MaxRange = (int)(DemandDistribution[i].CummProbability * 100);
                    }
                }
                for (int i = 0; i < LeadDaysDistribution.Count; i++)
                {
                    if (i == 0)
                    {
                        LeadDaysDistribution[i].CummProbability = LeadDaysDistribution[i].Probability;
                        LeadDaysDistribution[i].MinRange = 1;
                        LeadDaysDistribution[i].MaxRange = (int)(LeadDaysDistribution[i].CummProbability * 10);
                    }
                    else
                    {
                        LeadDaysDistribution[i].CummProbability = LeadDaysDistribution[i].Probability + LeadDaysDistribution[i - 1].CummProbability;
                        LeadDaysDistribution[i].MinRange = LeadDaysDistribution[i-1].MaxRange + 1;
                        LeadDaysDistribution[i].MaxRange = (int)(LeadDaysDistribution[i].CummProbability * 10);
                    }
                }


                int cycles=NumberOfDays/ReviewPeriod;
                int count=0;
                decimal sum_of_Ending=0;
                decimal sum_of_Shortage=0;
                int sum=0;
                Random random = new Random();
                for (int i = 1; i <= cycles; i++)
                {
                    for(int j=1;j<=ReviewPeriod;j++)
                    {
                        SimulationCase simulationCase = new SimulationCase();
                        simulationCase.Day = count+1;
                        simulationCase.Cycle=i;
                        simulationCase.DayWithinCycle=j;
                        simulationCase.RandomDemand = random.Next(1, 100);
                        for (int ii=0;ii<DemandDistribution.Count;ii++)
                        {
                            if (simulationCase.RandomDemand <= DemandDistribution[ii].MaxRange)
                            {
                                simulationCase.Demand =DemandDistribution[ii].Value;
                                break;
                            }
                        }
                        
                        if(StartLeadDays==0)
                        {
                            simulationCase.BeginningInventory=StartInventoryQuantity+StartOrderQuantity;
                            simulationCase.EndingInventory=simulationCase.BeginningInventory-simulationCase.Demand-sum;
                            StartOrderQuantity=0;
                            sum=0;
                            simulationCase.ShortageQuantity=0;
                        }
                        else
                        {
                            simulationCase.BeginningInventory=StartInventoryQuantity;
                            int x;
                            x=simulationCase.BeginningInventory-simulationCase.Demand;
                            if(x>0)
                            {
                                simulationCase.EndingInventory=x;
                                simulationCase.ShortageQuantity=0;
                            }
                            else
                            {
                                simulationCase.EndingInventory=0;
                                sum+=x*(-1);
                                simulationCase.ShortageQuantity=sum;
                            }
                            
                        }

                        StartInventoryQuantity=simulationCase.EndingInventory;
                        sum_of_Ending+=simulationCase.EndingInventory;
                        sum_of_Shortage+=simulationCase.ShortageQuantity;

                        if(j==ReviewPeriod)
                        {
                            simulationCase.OrderQuantity=(OrderUpTo-simulationCase.EndingInventory)+simulationCase.ShortageQuantity;
                            StartOrderQuantity=simulationCase.OrderQuantity;
                            simulationCase.RandomLeadDays=random.Next(1, 10);
                            for (int ii=0;ii<LeadDaysDistribution.Count;ii++)
                            {
                                if (simulationCase.RandomLeadDays <= LeadDaysDistribution[ii].MaxRange)
                                {
                                    simulationCase.LeadDays = LeadDaysDistribution[ii].Value;
                                    break;
                                }
                            }
                              if(simulationCase.LeadDays == 2)
                                  simulationCase.LeadDays = 1;
                            //simulationCase.DaysuntilOrderarrives=simulationCase.LeadDays;
                            StartLeadDays=simulationCase.LeadDays;
                          
                            

                        }
                        else
                        {
                            simulationCase.OrderQuantity=0;
                            simulationCase.RandomLeadDays=0;
                            simulationCase.LeadDays=0;
                            /*if(StartLeadDays>0)
                                simulationCase.DaysuntilOrderarrives=StartLeadDays-1;
                            else
                                simulationCase.DaysuntilOrderarrives=0;*/
                            StartLeadDays--;
                        }


                        count++;
                        SimulationCases.Add(simulationCase);
                    }
                    
                    

                    
                }

                //-- performance --//
                PerformanceMeasures.EndingInventoryAverage=sum_of_Ending/NumberOfDays;
                PerformanceMeasures.ShortageQuantityAverage=sum_of_Shortage/NumberOfDays;
            }
            finally
            {
                f.Close();
                sr.Close();
            }
        }

    }
}