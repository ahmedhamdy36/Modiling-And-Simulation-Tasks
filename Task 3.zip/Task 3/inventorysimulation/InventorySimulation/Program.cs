﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using InventoryTesting;
using InventoryModels;

namespace InventorySimulation
{
    static class Program
    {
        public static SimulationSystem system;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            system = new SimulationSystem(@"F:\level 4 , firest term\Modiling and semulation\Tasks\Task 3\inventorysimulation\InventorySimulation\TestCases\TestCase1.txt");
            string result = TestingManager.Test(system, Constants.FileNames.TestCase1);
            MessageBox.Show(result);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
