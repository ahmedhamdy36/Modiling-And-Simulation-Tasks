﻿namespace InventorySimulation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Day_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cycle_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DayWithin_Cycle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Beginning_Inv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Random_Demand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Demand_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndingInventory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShortageQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RandomLeadDays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LeadDays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Day_,
            this.Cycle_,
            this.DayWithin_Cycle,
            this.Beginning_Inv,
            this.Random_Demand,
            this.Demand_,
            this.EndingInventory,
            this.ShortageQuantity,
            this.OrderQuantity,
            this.RandomLeadDays,
            this.LeadDays});
            this.dataGridView2.Location = new System.Drawing.Point(103, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1250, 589);
            this.dataGridView2.TabIndex = 1;
            // 
            // Day_
            // 
            this.Day_.HeaderText = "Day_";
            this.Day_.Name = "Day_";
            // 
            // Cycle_
            // 
            this.Cycle_.HeaderText = "Cycle_";
            this.Cycle_.Name = "Cycle_";
            // 
            // DayWithin_Cycle
            // 
            this.DayWithin_Cycle.HeaderText = "DayWithin_Cycle";
            this.DayWithin_Cycle.Name = "DayWithin_Cycle";
            // 
            // Beginning_Inv
            // 
            this.Beginning_Inv.HeaderText = "Beginning_Inv";
            this.Beginning_Inv.Name = "Beginning_Inv";
            // 
            // Random_Demand
            // 
            this.Random_Demand.HeaderText = "Random_Demand";
            this.Random_Demand.Name = "Random_Demand";
            // 
            // Demand_
            // 
            this.Demand_.HeaderText = "Demand_";
            this.Demand_.Name = "Demand_";
            // 
            // EndingInventory
            // 
            this.EndingInventory.HeaderText = "EndingInventory";
            this.EndingInventory.Name = "EndingInventory";
            // 
            // ShortageQuantity
            // 
            this.ShortageQuantity.HeaderText = "ShortageQuantity";
            this.ShortageQuantity.Name = "ShortageQuantity";
            // 
            // OrderQuantity
            // 
            this.OrderQuantity.HeaderText = "OrderQuantity";
            this.OrderQuantity.Name = "OrderQuantity";
            // 
            // RandomLeadDays
            // 
            this.RandomLeadDays.HeaderText = "RandomLeadDays";
            this.RandomLeadDays.Name = "RandomLeadDays";
            // 
            // LeadDays
            // 
            this.LeadDays.HeaderText = "LeadDays";
            this.LeadDays.Name = "LeadDays";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1457, 601);
            this.Controls.Add(this.dataGridView2);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Day;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cycle;
        private System.Windows.Forms.DataGridViewTextBoxColumn Day_within_cycle;
        private System.Windows.Forms.DataGridViewTextBoxColumn Beginning_Inventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn Random_Digit_for_Demand;
        private System.Windows.Forms.DataGridViewTextBoxColumn Demand;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ending_Inventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn Shortage_Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Order_Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Random_Digit_for_LeadTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lead_Time;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Day_;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cycle_;
        private System.Windows.Forms.DataGridViewTextBoxColumn DayWithin_Cycle;
        private System.Windows.Forms.DataGridViewTextBoxColumn Beginning_Inv;
        private System.Windows.Forms.DataGridViewTextBoxColumn Random_Demand;
        private System.Windows.Forms.DataGridViewTextBoxColumn Demand_;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndingInventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShortageQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn RandomLeadDays;
        private System.Windows.Forms.DataGridViewTextBoxColumn LeadDays;
       // private System.Windows.Forms.DataGridViewTextBoxColumn Days_until_Order_arrives;
    }
}

