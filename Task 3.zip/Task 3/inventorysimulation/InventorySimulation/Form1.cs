﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InventoryTesting;

namespace InventorySimulation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
         }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView2.Rows.Add(Program.system.SimulationCases.Count);
            for (int i = 0; i < Program.system.SimulationCases.Count; i++)
            {
                dataGridView2.Rows[i].Cells[0].Value = Program.system.SimulationCases[i].Day.ToString();
                dataGridView2.Rows[i].Cells[1].Value = Program.system.SimulationCases[i].Cycle.ToString();
                dataGridView2.Rows[i].Cells[2].Value = Program.system.SimulationCases[i].DayWithinCycle.ToString();
                dataGridView2.Rows[i].Cells[3].Value = Program.system.SimulationCases[i].BeginningInventory.ToString();
                dataGridView2.Rows[i].Cells[4].Value = Program.system.SimulationCases[i].RandomDemand.ToString();
                dataGridView2.Rows[i].Cells[5].Value = Program.system.SimulationCases[i].Demand.ToString();
                dataGridView2.Rows[i].Cells[6].Value = Program.system.SimulationCases[i].EndingInventory.ToString();
                dataGridView2.Rows[i].Cells[7].Value = Program.system.SimulationCases[i].ShortageQuantity.ToString();
                dataGridView2.Rows[i].Cells[8].Value = Program.system.SimulationCases[i].OrderQuantity.ToString();
                dataGridView2.Rows[i].Cells[9].Value = Program.system.SimulationCases[i].RandomLeadDays.ToString();
                dataGridView2.Rows[i].Cells[10].Value = Program.system.SimulationCases[i].LeadDays.ToString();
              //dataGridView1.Rows[i].Cells[11].Value = Program.system.SimulationC//ases[i].DaysuntilOrderarrives.ToString();
            }

            
        }
    }
}
