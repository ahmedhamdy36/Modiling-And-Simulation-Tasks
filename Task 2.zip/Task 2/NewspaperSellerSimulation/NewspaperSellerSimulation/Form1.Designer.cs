﻿namespace NewspaperSellerSimulation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Day = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Random_digits_for_type_of_Newdays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type_of_Newdays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Random_digits_for_demond = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Demond = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Revenue_from_sales = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lost_profit_from_excess_demond = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salvage_fromsale_of_scrap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Daily_profit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Day,
            this.Random_digits_for_type_of_Newdays,
            this.Type_of_Newdays,
            this.Random_digits_for_demond,
            this.Demond,
            this.Revenue_from_sales,
            this.Lost_profit_from_excess_demond,
            this.salvage_fromsale_of_scrap,
            this.Daily_profit});
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1249, 554);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Day
            // 
            this.Day.HeaderText = "Day";
            this.Day.Name = "Day";
            // 
            // Random_digits_for_type_of_Newdays
            // 
            this.Random_digits_for_type_of_Newdays.HeaderText = "Random digits for type of Newdays";
            this.Random_digits_for_type_of_Newdays.Name = "Random_digits_for_type_of_Newdays";
            // 
            // Type_of_Newdays
            // 
            this.Type_of_Newdays.HeaderText = "Type of Newdays";
            this.Type_of_Newdays.Name = "Type_of_Newdays";
            // 
            // Random_digits_for_demond
            // 
            this.Random_digits_for_demond.HeaderText = "Random_digits_for_demond";
            this.Random_digits_for_demond.Name = "Random_digits_for_demond";
            // 
            // Demond
            // 
            this.Demond.HeaderText = "Demond";
            this.Demond.Name = "Demond";
            // 
            // Revenue_from_sales
            // 
            this.Revenue_from_sales.HeaderText = "Revenue_from_sales";
            this.Revenue_from_sales.Name = "Revenue_from_sales";
            // 
            // Lost_profit_from_excess_demond
            // 
            this.Lost_profit_from_excess_demond.HeaderText = "Lost_profit_from_excess_demond";
            this.Lost_profit_from_excess_demond.Name = "Lost_profit_from_excess_demond";
            // 
            // salvage_fromsale_of_scrap
            // 
            this.salvage_fromsale_of_scrap.HeaderText = "salvage_fromsale_of_scrap";
            this.salvage_fromsale_of_scrap.Name = "salvage_fromsale_of_scrap";
            // 
            // Daily_profit
            // 
            this.Daily_profit.HeaderText = "Daily_profit";
            this.Daily_profit.Name = "Daily_profit";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1273, 564);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Day;
        private System.Windows.Forms.DataGridViewTextBoxColumn Random_digits_for_type_of_Newdays;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type_of_Newdays;
        private System.Windows.Forms.DataGridViewTextBoxColumn Random_digits_for_demond;
        private System.Windows.Forms.DataGridViewTextBoxColumn Demond;
        private System.Windows.Forms.DataGridViewTextBoxColumn Revenue_from_sales;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lost_profit_from_excess_demond;
        private System.Windows.Forms.DataGridViewTextBoxColumn salvage_fromsale_of_scrap;
        private System.Windows.Forms.DataGridViewTextBoxColumn Daily_profit;
    }
}