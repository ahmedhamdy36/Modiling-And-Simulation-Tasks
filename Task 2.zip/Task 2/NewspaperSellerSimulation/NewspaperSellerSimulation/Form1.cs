﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NewspaperSellerModels;
using NewspaperSellerTesting;

namespace NewspaperSellerSimulation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(Program.system.SimulationTable.Count);
            for (int i = 0; i < Program.system.SimulationTable.Count; i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = Program.system.SimulationTable[i].DayNo.ToString();
                dataGridView1.Rows[i].Cells[1].Value = Program.system.SimulationTable[i].RandomNewsDayType.ToString();
                dataGridView1.Rows[i].Cells[2].Value = Program.system.SimulationTable[i].NewsDayType.ToString();
                dataGridView1.Rows[i].Cells[3].Value = Program.system.SimulationTable[i].RandomDemand.ToString();
                dataGridView1.Rows[i].Cells[4].Value = Program.system.SimulationTable[i].Demand.ToString();
                dataGridView1.Rows[i].Cells[5].Value = Program.system.SimulationTable[i].SalesProfit.ToString();
                dataGridView1.Rows[i].Cells[6].Value = Program.system.SimulationTable[i].LostProfit.ToString();
                dataGridView1.Rows[i].Cells[7].Value = Program.system.SimulationTable[i].ScrapProfit.ToString();
                dataGridView1.Rows[i].Cells[8].Value = Program.system.SimulationTable[i].DailyNetProfit.ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
