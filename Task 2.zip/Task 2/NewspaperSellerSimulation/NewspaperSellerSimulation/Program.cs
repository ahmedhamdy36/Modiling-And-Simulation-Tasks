﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using NewspaperSellerTesting;
using NewspaperSellerModels;

namespace NewspaperSellerSimulation
{
    static class Program
    {
        public static SimulationSystem system;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            system = new SimulationSystem(@"F:\level 4 , firest term\Modiling and semulation\Tasks\Task 2\NewspaperSellerSimulation_Students\NewspaperSellerSimulation\TestCases\TestCase3.txt");
            string result = TestingManager.Test(system, Constants.FileNames.TestCase3);
            MessageBox.Show(result);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
