﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace NewspaperSellerModels
{
    public class SimulationSystem
    {
        public SimulationSystem()
        {
            DayTypeDistributions = new List<DayTypeDistribution>();
            DemandDistributions = new List<DemandDistribution>();
            SimulationTable = new List<SimulationCase>();
            PerformanceMeasures = new PerformanceMeasures();
        }
        ///////////// INPUTS /////////////
        public int NumOfNewspapers { get; set; }
        public int NumOfRecords { get; set; }
        public decimal PurchasePrice { get; set; }
        public decimal SellingPrice { get; set; }
        public decimal ScrapPrice { get; set; }
        public decimal UnitProfit { get; set; }
        public List<DayTypeDistribution> DayTypeDistributions { get; set; }
        public List<DemandDistribution> DemandDistributions { get; set; }

        ///////////// OUTPUTS /////////////
        public List<SimulationCase> SimulationTable { get; set; }
        public PerformanceMeasures PerformanceMeasures { get; set; }


        public SimulationSystem(String file)
        {
            this.SimulationTable = new List<SimulationCase>();
            this.PerformanceMeasures = new PerformanceMeasures();
            this.DayTypeDistributions = new List<DayTypeDistribution>();
            this.DemandDistributions = new List<DemandDistribution>();

            FileStream f = new FileStream(file, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(f);
            String line;

            try
            {
                //-- Reading file --//
                line = sr.ReadLine();
                while (line != null)
                {
                    if (line.Contains("NumOfNewspapers"))
                    {
                        line = sr.ReadLine();

                        this.NumOfNewspapers = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("NumOfRecords"))
                    {
                        line = sr.ReadLine();

                        this.NumOfRecords = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("PurchasePrice"))
                    {
                        line = sr.ReadLine();

                        this.PurchasePrice = decimal.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("ScrapPrice"))
                    {
                        line = sr.ReadLine();

                        this.ScrapPrice = decimal.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("SellingPrice"))
                    {
                        line = sr.ReadLine();

                        this.SellingPrice = decimal.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("DayTypeDistributions"))
                    {
                        line = sr.ReadLine();

                        string[] arr = line.Split(',');

                        DayTypeDistribution tmp = new DayTypeDistribution();
                        tmp.DayType = Enums.DayType.Good;
                        tmp.Probability = decimal.Parse(arr[0]);
                        DayTypeDistributions.Add(tmp);

                        tmp = new DayTypeDistribution();
                        tmp.DayType = Enums.DayType.Fair;
                        tmp.Probability = decimal.Parse(arr[1]);
                        DayTypeDistributions.Add(tmp);

                        tmp = new DayTypeDistribution();
                        tmp.DayType = Enums.DayType.Poor;
                        tmp.Probability = decimal.Parse(arr[2]);
                        DayTypeDistributions.Add(tmp);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("DemandDistributions"))
                    {
                        while (true)
                        {
                            line = sr.ReadLine();

                            if (line == "" || line == null)
                                break;

                            DemandDistribution tmp = new DemandDistribution();
                            string[] arr = line.Split(',');
                            tmp.Demand = int.Parse(arr[0]);

                            DayTypeDistribution tmp2 = new DayTypeDistribution();
                            tmp2.DayType = Enums.DayType.Good;
                            tmp2.Probability = decimal.Parse(arr[1]);
                            tmp.DayTypeDistributions.Add(tmp2);

                            tmp2 = new DayTypeDistribution();
                            tmp2.DayType = Enums.DayType.Fair;
                            tmp2.Probability = decimal.Parse(arr[2]);
                            tmp.DayTypeDistributions.Add(tmp2);

                            tmp2 = new DayTypeDistribution();
                            tmp2.DayType = Enums.DayType.Poor;
                            tmp2.Probability = decimal.Parse(arr[3]);
                            tmp.DayTypeDistributions.Add(tmp2);

                            this.DemandDistributions.Add(tmp);
                        }

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                }


                //--- Cummulative Probability for semulation table ---//
                for (int i = 0; i < 3; i++)
                {
                    if (i == 0)
                    {
                        DayTypeDistributions[i].CummProbability = DayTypeDistributions[i].Probability;
                        DayTypeDistributions[i].MinRange = 1;
                        DayTypeDistributions[i].MaxRange = (int)(DayTypeDistributions[i].CummProbability * 100);
                    }
                    else
                    {
                        DayTypeDistributions[i].CummProbability = DayTypeDistributions[i].Probability + DayTypeDistributions[i - 1].CummProbability;
                        DayTypeDistributions[i].MinRange = DayTypeDistributions[i-1].MaxRange + 1;
                        DayTypeDistributions[i].MaxRange = (int)(DayTypeDistributions[i].CummProbability * 100);
                    }
                }


                //--- Demand calculations ---//
                for (int n = 0; n < DemandDistributions.Count; n++)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        if (n == 0)
                        {
                            DemandDistributions[n].DayTypeDistributions[i].CummProbability = DemandDistributions[n].DayTypeDistributions[i].Probability;
                            DemandDistributions[n].DayTypeDistributions[i].MinRange = 1;
                            DemandDistributions[n].DayTypeDistributions[i].MaxRange = (int)(DemandDistributions[n].DayTypeDistributions[i].Probability * 100);
                        }
                        else
                        {
                            if (DemandDistributions[n].DayTypeDistributions[i].Probability == 0)
                            {
                                DemandDistributions[n].DayTypeDistributions[i].MinRange = 0;
                                DemandDistributions[n].DayTypeDistributions[i].MaxRange = 0;
                            }
                            else
                            {
                                DemandDistributions[n].DayTypeDistributions[i].CummProbability = DemandDistributions[n].DayTypeDistributions[i].Probability + DemandDistributions[n - 1].DayTypeDistributions[i].CummProbability;
                                DemandDistributions[n].DayTypeDistributions[i].MinRange = DemandDistributions[n - 1].DayTypeDistributions[i].MaxRange + 1;
                                DemandDistributions[n].DayTypeDistributions[i].MaxRange = (int)(DemandDistributions[n].DayTypeDistributions[i].CummProbability * 100);
                            }
                        }
                    }
                }

                decimal TotalSalesProfit = 0;
                decimal TotalLostProfit = 0;
                decimal TotalScrapProfit = 0;
                decimal TotalDailyCost = 0;
                decimal TotalDailyNetProfit = 0;
                int daysWithMoreDemand = 0;
                int daysWithUnsoldPapers = 0;
                
                Random random = new Random();
                for (int i = 0; i < NumOfRecords; i++)
                {
                    SimulationCase simulationCase = new SimulationCase();
                    
                    simulationCase.DayNo = i+1;
                    
                    
                    //-- DayType - Rondom --// 
                    simulationCase.RandomNewsDayType = random.Next(1, 100);
                    for (int j = 0; j < DayTypeDistributions.Count; j++)
                    {
                        if (simulationCase.RandomNewsDayType <= DayTypeDistributions[j].MaxRange)
                        {
                            simulationCase.NewsDayType = DayTypeDistributions[j].DayType;
                            break;
                        }
                    }

                    
                    //-- select Demond --//
                    int check = 0;
                    if (simulationCase.NewsDayType == Enums.DayType.Fair)
                        check = 1;
                    else if (simulationCase.NewsDayType == Enums.DayType.Poor)
                        check = 2;

                    simulationCase.RandomDemand = random.Next(1, 100);
                    for (int j = 0; j < DemandDistributions.Count; j++)
                    {
                        if (simulationCase.RandomDemand <= DemandDistributions[j].DayTypeDistributions[check].MaxRange)
                        {
                            simulationCase.Demand = DemandDistributions[j].Demand;
                            break;
                        }
                    }


                    //-- claculate profit --//
                    if (this.NumOfNewspapers < simulationCase.Demand)
                    {
                        simulationCase.SalesProfit = (decimal)(this.NumOfNewspapers * this.SellingPrice);
                        TotalSalesProfit += simulationCase.SalesProfit;
                    }
                    else
                    {
                        simulationCase.SalesProfit = (decimal)(simulationCase.Demand * this.SellingPrice);
                        TotalSalesProfit += simulationCase.SalesProfit;
                    }
                    
                    
                    //-- Calculate LostProfit - ScrapProfit --//
                    if (simulationCase.Demand < NumOfNewspapers)
                    {
                        simulationCase.LostProfit = 0;
                        daysWithUnsoldPapers+=1;
                        simulationCase.ScrapProfit = (decimal)((NumOfNewspapers - simulationCase.Demand) * this.ScrapPrice);
                        TotalScrapProfit += simulationCase.ScrapProfit;
                    }
                    else if (simulationCase.Demand > NumOfNewspapers)
	                {
                        simulationCase.ScrapProfit = 0;
                        daysWithMoreDemand+=1;
                        simulationCase.LostProfit = (decimal)((simulationCase.Demand - NumOfNewspapers) * (this.SellingPrice - this.PurchasePrice));
                        TotalLostProfit += simulationCase.LostProfit;
                    }
                    else
                    {
                        simulationCase.ScrapProfit = 0;
                        simulationCase.LostProfit = 0;
                    }

                    
                    //-- Calculate DailyCost --//
                    simulationCase.DailyCost = this.NumOfNewspapers * this.PurchasePrice;
                    TotalDailyCost += simulationCase.DailyCost;

                
                    //-- Calculate DailyNetProfit --//
                    simulationCase.DailyNetProfit = simulationCase.SalesProfit - simulationCase.DailyCost - simulationCase.LostProfit + simulationCase.ScrapProfit;
                    TotalDailyNetProfit += simulationCase.DailyNetProfit;


                    SimulationTable.Add(simulationCase);
                }


                //-- performance --//
                PerformanceMeasures.TotalSalesProfit = TotalSalesProfit;
                PerformanceMeasures.TotalCost = TotalDailyCost;
                PerformanceMeasures.TotalLostProfit = TotalLostProfit;
                PerformanceMeasures.TotalScrapProfit = TotalScrapProfit;
                PerformanceMeasures.TotalNetProfit = TotalDailyNetProfit;
                PerformanceMeasures.DaysWithMoreDemand = daysWithMoreDemand;
                PerformanceMeasures.DaysWithUnsoldPapers = daysWithUnsoldPapers;
            }
            finally
            {
                f.Close();
                sr.Close();
            }
        }
    }
}
