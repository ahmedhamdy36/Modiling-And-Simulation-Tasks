﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewspaperSellerModels
{
    public class Enums
    {
        public enum DayType
        {
            Good = 0,
            Fair = 1,
            Poor = 2
        }
    }
}
