﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MultiQueueModels;
using MultiQueueTesting;
using System.IO;


namespace MultiQueueSimulation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          // dataGridView1.DataSource = Program.system.SimulationTable;
           dataGridView1.Rows.Add(Program.system.SimulationTable.Count);
           for (int i = 0; i < Program.system.SimulationTable.Count; i++)
           {
               dataGridView1.Rows[i].Cells[0].Value = Program.system.SimulationTable[i].CustomerNumber.ToString();
               dataGridView1.Rows[i].Cells[1].Value = Program.system.SimulationTable[i].RandomInterArrival.ToString();
               dataGridView1.Rows[i].Cells[2].Value = Program.system.SimulationTable[i].InterArrival.ToString();
               dataGridView1.Rows[i].Cells[3].Value = Program.system.SimulationTable[i].ArrivalTime.ToString();
               dataGridView1.Rows[i].Cells[4].Value = Program.system.SimulationTable[i].RandomService.ToString();
               dataGridView1.Rows[i].Cells[5].Value = Program.system.SimulationTable[i].ServiceTime.ToString();
               dataGridView1.Rows[i].Cells[6].Value = Program.system.SimulationTable[i].AssignedServer.ID.ToString();
               dataGridView1.Rows[i].Cells[7].Value = Program.system.SimulationTable[i].StartTime.ToString();
               dataGridView1.Rows[i].Cells[8].Value = Program.system.SimulationTable[i].EndTime.ToString();
               dataGridView1.Rows[i].Cells[9].Value = Program.system.SimulationTable[i].TimeInQueue.ToString();

           }

           for (int i = 0; i < Program.system.Servers.Count; i++)
           {

               new graph(i).Show();
           
           }

        }

   
    }
}
