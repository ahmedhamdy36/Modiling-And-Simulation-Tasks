﻿namespace MultiQueueSimulation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.customernumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.randominterarrival = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interarrival = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arrivaltime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.randomservies = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servisetime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assigendserves = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.starttime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endtime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeinqueu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customernumber,
            this.randominterarrival,
            this.interarrival,
            this.arrivaltime,
            this.randomservies,
            this.servisetime,
            this.assigendserves,
            this.starttime,
            this.endtime,
            this.timeinqueu});
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(916, 527);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // customernumber
            // 
            this.customernumber.HeaderText = "customernumber";
            this.customernumber.Name = "customernumber";
            // 
            // randominterarrival
            // 
            this.randominterarrival.HeaderText = "randominterarrival";
            this.randominterarrival.Name = "randominterarrival";
            // 
            // interarrival
            // 
            this.interarrival.HeaderText = "interarrival";
            this.interarrival.Name = "interarrival";
            // 
            // arrivaltime
            // 
            this.arrivaltime.HeaderText = "arrivaltime";
            this.arrivaltime.Name = "arrivaltime";
            // 
            // randomservies
            // 
            this.randomservies.HeaderText = "randomservies";
            this.randomservies.Name = "randomservies";
            // 
            // servisetime
            // 
            this.servisetime.HeaderText = "servisetime";
            this.servisetime.Name = "servisetime";
            // 
            // assigendserves
            // 
            this.assigendserves.HeaderText = "assigendserves";
            this.assigendserves.Name = "assigendserves";
            // 
            // starttime
            // 
            this.starttime.HeaderText = "starttime";
            this.starttime.Name = "starttime";
            // 
            // endtime
            // 
            this.endtime.HeaderText = "endtime";
            this.endtime.Name = "endtime";
            // 
            // timeinqueu
            // 
            this.timeinqueu.HeaderText = "timeinqueu";
            this.timeinqueu.Name = "timeinqueu";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 621);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn customernumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn randominterarrival;
        private System.Windows.Forms.DataGridViewTextBoxColumn interarrival;
        private System.Windows.Forms.DataGridViewTextBoxColumn arrivaltime;
        private System.Windows.Forms.DataGridViewTextBoxColumn randomservies;
        private System.Windows.Forms.DataGridViewTextBoxColumn servisetime;
        private System.Windows.Forms.DataGridViewTextBoxColumn assigendserves;
        private System.Windows.Forms.DataGridViewTextBoxColumn starttime;
        private System.Windows.Forms.DataGridViewTextBoxColumn endtime;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeinqueu;
    }
}

