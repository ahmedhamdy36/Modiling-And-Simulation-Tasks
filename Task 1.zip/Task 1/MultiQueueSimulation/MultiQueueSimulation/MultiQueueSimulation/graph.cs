﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiQueueSimulation
{
    public partial class graph : Form
    {
        public graph(int i )
        {
            InitializeComponent();


           

                chart1.Series.Add("server ID" + Program.system.Servers[i].ID.ToString());
                chart1.ChartAreas[0].AxisX.Minimum = 1;
                chart1.ChartAreas[0].AxisX.Maximum = Program.system.Servers[i].FinishTime;
                chart1.ChartAreas[0].AxisX.Interval = 1;
                chart1.ChartAreas[0].AxisY.Interval = 1;

                foreach(KeyValuePair<int,int> n in Program.system.Servers[i].SFtime)
                {

                    for(int s =n.Key; s<=n.Value;s++)
                    {
                        chart1.Series[0].Points.AddXY(s, 1);

                    }

                }
            }
        

        private void graph_Load(object sender, EventArgs e)
        {
           





        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}
