﻿NumberOfServers
// value of number of servers 

StoppingNumber
// stopping condition when reaching the maxnum number of customers or simulation endtime

StoppingCriteria
// the criteria on which the simulation will end => Enums.StoppingCriteria.NumberOfCustomers or Enums.StoppingCriteria.SimulationEndTime

SelectionMethod
// the method by which the servers will be selected => Enums.SelectionMethod.HighestPriority or Enums.SelectionMethod.Random or Enums.SelectionMethod.LeastUtilization

InterarrivalDistribution
// The interarrival distribution by which arrival between customers are simulated

ServiceDistribution_Server1
// The service time distribution that server1 takes to serve customers

ServiceDistribution_Server2
// The service time distribution that server2 takes to serve customers