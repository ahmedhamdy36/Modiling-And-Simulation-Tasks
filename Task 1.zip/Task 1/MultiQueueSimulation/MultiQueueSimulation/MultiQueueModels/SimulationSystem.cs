﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MultiQueueModels
{
    public class SimulationSystem
    {
        public SimulationSystem()
        {
            this.Servers = new List<Server>();
            this.InterarrivalDistribution = new List<TimeDistribution>();
            this.PerformanceMeasures = new PerformanceMeasures();
            this.SimulationTable = new List<SimulationCase>();
        }

        ///////////// INPUTS ///////////// 
        public int NumberOfServers { get; set; }
        public int StoppingNumber { get; set; }
        public List<Server> Servers { get; set; }
        public List<TimeDistribution> InterarrivalDistribution { get; set; }
        public Enums.StoppingCriteria StoppingCriteria { get; set; }
        public Enums.SelectionMethod SelectionMethod { get; set; }
        public int TotalSimulationTime { get; set; }

        ///////////// OUTPUTS /////////////
        public List<SimulationCase> SimulationTable { get; set; }
        public PerformanceMeasures PerformanceMeasures { get; set; }


        public SimulationSystem(String file)
        {
            this.Servers = new List<Server>();
            this.InterarrivalDistribution = new List<TimeDistribution>();
            this.PerformanceMeasures = new PerformanceMeasures();
            this.SimulationTable = new List<SimulationCase>();
            this.TotalSimulationTime = 0;

            FileStream f = new FileStream(file, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(f);
            String line;


            //--- reading file ---//
            try
            {
                line = sr.ReadLine();
                while (line != null)
                {
                    if (line.Contains("NumberOfServers"))
                    {
                        line = sr.ReadLine();

                        this.NumberOfServers = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("StoppingNumber"))
                    {
                        line = sr.ReadLine();

                        this.StoppingNumber = int.Parse(line);

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("StoppingCriteria"))
                    {
                        line = sr.ReadLine();

                        if (int.Parse(line) == 1)
                            this.StoppingCriteria = Enums.StoppingCriteria.NumberOfCustomers;
                        if (int.Parse(line) == 2)
                            this.StoppingCriteria = Enums.StoppingCriteria.SimulationEndTime;

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("SelectionMethod"))
                    {
                        line = sr.ReadLine();

                        if (int.Parse(line) == 1)
                            this.SelectionMethod = Enums.SelectionMethod.HighestPriority;
                        if (int.Parse(line) == 2)
                            this.SelectionMethod = Enums.SelectionMethod.Random;
                        if (int.Parse(line) == 3)
                            this.SelectionMethod = Enums.SelectionMethod.LeastUtilization;

                        line = sr.ReadLine();
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("InterarrivalDistribution"))
                    {
                        while (true)
                        {
                            TimeDistribution tmp = new TimeDistribution();
                            line = sr.ReadLine();

                            if (line == "" || line == null)
                                break;

                            string[] arr = line.Split(',');
                            tmp.Time = Int32.Parse(arr[0]);
                            tmp.Probability = Convert.ToDecimal(arr[1]);
                            this.InterarrivalDistribution.Add(tmp);
                        }
                        line = sr.ReadLine();
                    }
                    else if (line.Contains("ServiceDistribution"))
                    {
                        int counter = 1;
                        while (true)
                        {
                            Server server = new Server();
                            line = sr.ReadLine();

                            if (line == "" || line == null)
                                break;

                            while (true)
                            {
                                TimeDistribution tmp = new TimeDistribution();
                                string[] arr = line.Split(',');
                                tmp.Time = Int32.Parse(arr[0]);
                                tmp.Probability = Convert.ToDecimal(arr[1]);
                                server.TimeDistribution.Add(tmp);
                                line = sr.ReadLine();

                                if (line == "" || line == null)
                                    break;
                            }

                            server.ID = counter;
                            this.Servers.Add(server);
                            counter++;
                            line = sr.ReadLine();
                        }
                    }
                }

                //--- CummProbability and Range for semulation system ---//
                for (int i = 0; i < InterarrivalDistribution.Count; i++)
                {
                    if (i == 0)
                    {
                        InterarrivalDistribution[i].CummProbability = InterarrivalDistribution[i].Probability;
                        InterarrivalDistribution[i].MinRange = 1;
                        InterarrivalDistribution[i].MaxRange = Decimal.ToInt32((InterarrivalDistribution[i].CummProbability) * 100);
                    }
                    else
                    {
                        InterarrivalDistribution[i].CummProbability = InterarrivalDistribution[i].Probability + InterarrivalDistribution[i - 1].CummProbability;
                        InterarrivalDistribution[i].MinRange = InterarrivalDistribution[i - 1].MaxRange + 1;
                        InterarrivalDistribution[i].MaxRange = Decimal.ToInt32((InterarrivalDistribution[i].CummProbability) * 100);
                    }
                }

                //--- CummProbability and Range for each server  ---//
                for (int i = 0; i < Servers.Count; i++)
                {
                    Decimal cum = 0;
                    for (int j = 0; j < this.Servers[i].TimeDistribution.Count; j++)
                    {
                        this.Servers[i].TimeDistribution[j].CummProbability = this.Servers[i].TimeDistribution[j].Probability + cum;
                        if (j == 0)
                        {
                            this.Servers[i].TimeDistribution[j].MinRange = 1;
                            this.Servers[i].TimeDistribution[j].MaxRange = Decimal.ToInt32((Servers[i].TimeDistribution[j].CummProbability) * 100);
                        }
                        else
                        {
                            this.Servers[i].TimeDistribution[j].MinRange = Servers[i].TimeDistribution[j - 1].MaxRange + 1;
                            this.Servers[i].TimeDistribution[j].MaxRange = Decimal.ToInt32((Servers[i].TimeDistribution[j].CummProbability) * 100);
                        }
                        cum = this.Servers[i].TimeDistribution[j].CummProbability;
                    }
                }

                //--- selection craitiria ---//
                Random r = new Random();
                SimulationCase ss = new SimulationCase();
                Decimal fss = 0;
                Decimal customerwating = 0;
                int mostNumOfCustInQue = 0;

                for (int i = 0; i < this.StoppingNumber; i++)
                {
                    int num = 0;
                    if (this.SelectionMethod == Enums.SelectionMethod.HighestPriority)
                    {
                        SimulationCase tmp = new SimulationCase();
                        tmp.CustomerNumber = i + 1;
                        if (i == 0)
                        {
                            tmp.ArrivalTime = 0;
                            tmp.RandomInterArrival = 1;
                            tmp.RandomService = r.Next(1, 100);
                            tmp.AssignedServer = this.Servers[0];
                            tmp.StartTime = 0;

                            //--- caculate service time---//
                            for (int j = 0; j < this.Servers[0].TimeDistribution.Count; j++)
                            {
                                if (tmp.RandomService <= this.Servers[0].TimeDistribution[j].MaxRange && tmp.RandomService >= this.Servers[0].TimeDistribution[j].MinRange)
                                {
                                    tmp.ServiceTime = this.Servers[0].TimeDistribution[j].Time;
                                    break;
                                }
                            }
                            tmp.EndTime = tmp.ServiceTime;
                            this.Servers[0].FinishTime = tmp.EndTime;
                            tmp.TimeInQueue = 0;
                        }
                        else
                        {
                            tmp.RandomInterArrival = r.Next(1, 100);

                            //--- calculate Interval Time ---//
                            for (int ii = 0; ii < this.InterarrivalDistribution.Count; ii++)
                            {
                                if (tmp.RandomInterArrival <= this.InterarrivalDistribution[ii].MaxRange && tmp.RandomInterArrival >= this.InterarrivalDistribution[ii].MinRange)
                                {
                                    tmp.InterArrival = this.InterarrivalDistribution[ii].Time;
                                    break;
                                }
                            }
                            tmp.ArrivalTime = tmp.InterArrival + this.SimulationTable[i - 1].ArrivalTime;

                            int g = this.Servers[0].FinishTime;
                            int uo = 0;

                            //--- Assign sever---//
                            for (int y = 0; y < this.Servers.Count; y++)
                            {
                                if (g > this.Servers[y].FinishTime)
                                {
                                    g = this.Servers[y].FinishTime;
                                    uo = y;
                                }
                                if (this.Servers[y].FinishTime <= tmp.ArrivalTime)
                                {
                                    tmp.AssignedServer = this.Servers[y];
                                    num = y;
                                    break;
                                }
                                if (y + 1 == this.Servers.Count)
                                {
                                    tmp.AssignedServer = this.Servers[uo];
                                    num = uo;
                                }
                            }

                            //--- Start time ---//
                            if (tmp.ArrivalTime > this.Servers[num].FinishTime)
                                tmp.StartTime = tmp.ArrivalTime;
                            else
                                tmp.StartTime = this.Servers[num].FinishTime;

                            tmp.RandomService = r.Next(1, 100);

                            //--- service time ---//
                            for (int j = 0; j < Servers[num].TimeDistribution.Count; j++)
                            {
                                if (tmp.RandomService <= Servers[num].TimeDistribution[j].MaxRange && tmp.RandomService >= Servers[num].TimeDistribution[j].MinRange)
                                {
                                    tmp.ServiceTime = Servers[num].TimeDistribution[j].Time;
                                    break;
                                }
                            }
                        }


                        //--- calculate time in queue and custumers in queue ---//
                        int you = this.Servers[0].FinishTime;
                        for (int x = 0; x < this.NumberOfServers; x++)
                        {
                            if (i == 0)
                                break;
                            else if (tmp.ArrivalTime >= this.Servers[x].FinishTime)
                                break;
                            else if (tmp.ArrivalTime < this.Servers[x].FinishTime)
                            {
                                if (you > this.Servers[x].FinishTime)
                                    you = this.Servers[x].FinishTime;
                                if (x == this.NumberOfServers - 1)
                                {
                                    tmp.TimeInQueue = you - tmp.ArrivalTime;
                                    customerwating += 1;
                                    fss += tmp.TimeInQueue ;
                                }
                            }
                        }

                        //--- Maximum length in queue ---//
                        for (int b = 0; b < SimulationTable.Count; b++)
                        {
                            int yl = 0;
                            if (tmp.TimeInQueue > 0)
                            {
                                yl = 1;
                                for (int z = b + 1; z < SimulationTable.Count; z++)
                                {
                                    if (SimulationTable[b].StartTime > SimulationTable[z].ArrivalTime)
                                        yl++;
                                    if (yl > mostNumOfCustInQue)
                                        mostNumOfCustInQue = yl;
                                }
                            }
                        }

                        tmp.EndTime = tmp.ServiceTime + tmp.StartTime;
                        this.Servers[num].FinishTime = tmp.EndTime;
                        this.PerformanceMeasures.AverageWaitingTime = fss / tmp.CustomerNumber;
                        this.PerformanceMeasures.MaxQueueLength = mostNumOfCustInQue;
                        this.PerformanceMeasures.WaitingProbability = customerwating / tmp.CustomerNumber;
                        this.SimulationTable.Add(tmp);
                        tmp.AssignedServer.SFtime.Add(new KeyValuePair<int, int>(tmp.StartTime, tmp.EndTime));
                    }
                    else if (this.SelectionMethod == Enums.SelectionMethod.Random)
                    {
                        SimulationCase tmp = new SimulationCase();
                        tmp.CustomerNumber = i + 1;
                        int var = this.Servers.Count();
                        int fs = r.Next(1, var);
                        if (i == 0)
                        {
                            tmp.ArrivalTime = 0;
                            tmp.RandomInterArrival = 1;
                            tmp.RandomService = r.Next(1, 100);
                            tmp.AssignedServer = this.Servers[fs];
                            tmp.StartTime = 0;


                            for (int j = 0; j < this.Servers[fs].TimeDistribution.Count; j++)
                            {
                                if (tmp.RandomService <= this.Servers[fs].TimeDistribution[j].MaxRange && tmp.RandomService >= this.Servers[fs].TimeDistribution[j].MinRange)
                                {
                                    tmp.ServiceTime = this.Servers[fs].TimeDistribution[j].Time;
                                    break;
                                }
                            }

                            tmp.EndTime = tmp.ServiceTime;
                            this.Servers[fs].FinishTime = tmp.EndTime;
                            tmp.TimeInQueue = 0;
                        }
                        else
                        {
                            tmp.RandomInterArrival = r.Next(1, 100);
                            for (int ii = 0; ii < this.InterarrivalDistribution.Count; ii++)
                            {
                                if (tmp.RandomInterArrival <= this.InterarrivalDistribution[ii].MaxRange && tmp.RandomInterArrival >= this.InterarrivalDistribution[ii].MinRange)
                                {
                                    tmp.InterArrival = this.InterarrivalDistribution[ii].Time;
                                    break;
                                }
                            }
                            tmp.ArrivalTime = tmp.InterArrival + this.SimulationTable[i - 1].ArrivalTime;

                            int g = this.Servers[fs].FinishTime;
                            int uo = 0;

                            for (int y = 0; y < this.Servers.Count; y++)
                            {

                                if (g > this.Servers[y].FinishTime)
                                {
                                    g = this.Servers[y].FinishTime;
                                    uo = y;
                                }
                                if (this.Servers[y].FinishTime <= tmp.ArrivalTime)
                                {
                                    tmp.AssignedServer = this.Servers[y];
                                    break;
                                }
                                if (y + 1 == this.Servers.Count)
                                    tmp.AssignedServer = this.Servers[uo];
                            }

                            if (tmp.ArrivalTime > this.Servers[fs].FinishTime)
                                tmp.StartTime = tmp.ArrivalTime;
                            else
                                tmp.StartTime = this.Servers[fs].FinishTime;

                            tmp.RandomService = r.Next(1, 100);
                            for (int j = 0; j < Servers[fs].TimeDistribution.Count; j++)
                            {
                                if (tmp.RandomService <= Servers[fs].TimeDistribution[j].MaxRange && tmp.RandomService >= Servers[fs].TimeDistribution[j].MinRange)
                                {
                                    tmp.ServiceTime = Servers[fs].TimeDistribution[j].Time;

                                    break;
                                }
                            }

                        }
                        for (int x = 0; x < this.NumberOfServers; x++)
                        {
                            if (i == 0)
                            {
                                break;
                            }
                            else if (tmp.ArrivalTime >= this.Servers[x].FinishTime)
                            {
                                break;
                            }
                            if (x == this.NumberOfServers - 1)
                            {

                                tmp.TimeInQueue = this.Servers[x].FinishTime - tmp.ArrivalTime;
                                customerwating += 1;
                                fss = (tmp.TimeInQueue + fss);
                            }
                        }
                        for (int b = 0; b < SimulationTable.Count; b++)
                        {
                            int yl = 0;
                            if (tmp.TimeInQueue > 1)
                            {
                                yl = 1;

                                for (int z = b + 1; z < SimulationTable.Count; z++)
                                {
                                    if (SimulationTable[b].StartTime > SimulationTable[z].ArrivalTime)
                                    {
                                        yl++;

                                    }
                                    if (yl > mostNumOfCustInQue)
                                    {
                                        mostNumOfCustInQue = yl;
                                    }
                                }
                            }
                        }

                        tmp.EndTime = tmp.ServiceTime + tmp.StartTime;
                        this.Servers[fs].FinishTime = tmp.EndTime;
                        this.PerformanceMeasures.AverageWaitingTime = fss / tmp.CustomerNumber;
                        this.PerformanceMeasures.MaxQueueLength = mostNumOfCustInQue;
                        this.PerformanceMeasures.WaitingProbability = customerwating / tmp.CustomerNumber;
                        this.SimulationTable.Add(tmp);
                    }
                }

                //--- calculate TotalWorkingTime and Number of customer per server---//
                for (int i = 0; i < this.SimulationTable.Count; i++)
                {
                    this.SimulationTable[i].AssignedServer.TotalWorkingTime += this.SimulationTable[i].ServiceTime;
                    this.SimulationTable[i].AssignedServer.number_customer++;
                }

                //--- calculate AverageServiceTime ---//
                for (int i = 0; i < Servers.Count; i++)
                {
                    if (this.Servers[i].number_customer == 0)
                        break;
                    this.Servers[i].AverageServiceTime = this.Servers[i].TotalWorkingTime / this.Servers[i].number_customer;
                }

                //--- calculate TotalSimulationTime for simulation ---//
                int max = -10000000;
                for (int i = 0; i < SimulationTable.Count; i++)
                {
                    int current = SimulationTable[i].EndTime;
                    if (current > max) 
                        max = current;

                }
                TotalSimulationTime = max;

                //--- calculate IdleProbability per server ---//
                int TotalIdleTime;
                for (int i = 0; i < Servers.Count; i++)
                {
                    TotalIdleTime = TotalSimulationTime - Servers[i].TotalWorkingTime;
                    if (TotalSimulationTime != 0)
                        Servers[i].IdleProbability = (decimal)TotalIdleTime / TotalSimulationTime;
                    else
                        Servers[i].IdleProbability = 0;
                }

                //--- calculate Utilization per server ---//
                for (int i = 0; i < Servers.Count; i++)
                {
                    if (TotalSimulationTime != 0)
                        Servers[i].Utilization = (decimal)Servers[i].TotalWorkingTime / TotalSimulationTime;
                    else
                        Servers[i].Utilization = 0;
                }
            }
            finally
            {
                f.Close();
                sr.Close();
            }
        }
    }
}